%% LQG loop transfer recover (LTR).
% Example taken from Doyle & Stein, "Robustness with Observers",
% IEEE Trans. Aut. Control, 24:4, 1979

n = 2;
A = [0 1
    -3 -4];
C = [2 1];

B = [0;1];


H = [50 10];
Q = H'*H;
R = 1;

[K, P] = lqr(A,B,Q,R);

LoopLQR = ss(A,B,K,0);

figure(5);nyquist(LoopLQR)
hold on
rectangle('Position', [-2, -1, 2, 2], 'Curvature', [1 1], 'EdgeColor', 'r')
hold off
axis([-3 1 -2 2])
%%
obsv(A,C)

G = ss(A,B,C,0);
Bw = [35;-61];

[E, L] = kalman(ss(A,eye(2),C,0),Bw*Bw',1);

KalmanFilter = ss(A-L*C,L,eye(n),0);

Loop = K*KalmanFilter*G;

figure(5);
hold on;
nyquist(Loop)
hold off;

%%

q = 1e6;

[E, L] = kalman(ss(A,eye(2),C,0),Bw*Bw'+q*B*B',1);
KalmanFilter = ss(A-L*C,L,eye(n),0);

Loop = K*KalmanFilter*G;
figure(5)
hold on;
nyquist(Loop)
hold off;
legend('LQR', 'LQG', 'LQG-LTR')