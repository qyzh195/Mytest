%% Control of F-14 Lateral Axis Using mu-Synthesis
% In this demo we'll show how to use mu-analysis and synthesis tools in the
% Robust Control Toolbox(TM). Our example describes the design of a robust
% controller for the lateral-directional axis of an F-14 aircraft during
% powered approach to landing. The linearized F-14 model is found at an
% angle-of-attack (|alpha|) of 10.5 degrees and airspeed of 140 knots.   

%   Copyright 1986-2011 The MathWorks, Inc.
%   $Revision: 1.1.6.8.2.1 $ $Date: 2011/07/01 16:40:27 $

%% Performance Specifications
% Let's look at the illustration below showing a block diagram of the
% closed-loop system. The diagram includes the nominal aircraft model, the
% controller |K|, as well as elements capturing the model uncertainty and
% performance objectives (see next sections for details).
%

%%
% *Figure 1:* Robust Control Design for F-14 Lateral Axis

%%
% Our design goal is to have the "true" airplane respond 
% effectively to the pilot's lateral stick and rudder
% pedal inputs. These performance specifications include:
%
% * Decoupled responses from lateral stick to roll rate |p|
% and from rudder pedals to side-slip angle |beta|. The lateral
% stick and rudder pedals have a maximum deflection of +/- 1
% inch.
%
% * The aircraft handling quality (HQ) response from 
% lateral stick to roll rate |p| should match the first-order response

hq_p    = 5.0 * tf(2.0,[1 2.0]);
figure(1);
step(hq_p), title('Desired response from lateral stick to roll rate (Handling Quality)')

%%
% *Figure 2:* Desired response from lateral stick to roll rate. 

%%
% The aircraft handling quality response from the rudder pedals to the
% side-slip angle |beta| should match the damped second-order response. 

hq_beta = -2.5 * tf(1.25^2,[1 2.5 1.25^2]);
figure(2);
step(hq_beta), title('Desired response from rudder pedal to side-slip angle (Handling Quality)')

%%
% *Figure 3:* Desired response from rudder pedal to side-slip angle.

%%
% * The stabilizer actuators have +/- 20 degs and +/- 90
% degs/sec limits on their deflection and deflection rate.  The rudder
% actuators have +/- 30 degs and +/-125 degs/sec deflection
% and deflection rate limits.
%
% * The three measurement signals ( roll rate |p|, yaw rate |r|, 
% and lateral acceleration |y_ac| ) are filtered through 
% second-order anti-aliasing filters:

freq = 12.5 * (2*pi);  % 12.5 Hz
zeta = 0.5;
antia_filt_yaw = tf(freq^2,[1 2*zeta*freq freq^2]);
antia_filt_lat = tf(freq^2,[1 2*zeta*freq freq^2]);

freq = 4.1 * (2*pi);  % 4.1 Hz
zeta = 0.7;
antia_filt_roll = tf(freq^2,[1 2*zeta*freq freq^2]);

antia_filt = append(antia_filt_roll,antia_filt_yaw,antia_filt_lat);

   
%% From Specs to Weighting Functions
% Note that H-infinity design algorithms seek to minimize the largest 
% closed-loop gain across frequency (H-infinity norm). To apply
% these tools, we first must recast our design tradeoffs and
% frequency-dependent specifications as constraints on the closed-loop
% gains. We'll use *weighting  functions* to "normalize" our specifications  
% across frequency and to weight each requirement adequately. 
%
% We'll express the F14 specs in terms of weighting functions:
%
% * To capture the limits on the actuator deflection magnitude and
%   rate, pick a diagonal, constant weight, such as |W_act|, corresponding
%   to the stabilizer and rudder deflection rate and deflection limits. 

W_act = diag([1/90,1/20,1/125,1/30]);

%%
% * We can use a 3x3 diagonal, high-pass filter |W_n| to model the frequency
% content of the sensor noise in the roll rate, yaw rate, and lateral
% acceleration channels.
figure(3)
W_n = append(0.025,tf(0.0125*[1 1],[1 100]),0.025);
clf, bodemag(W_n(2,2)), title('Sensor noise power as a function of frequency')

%%
% *Figure 4:* Sensor noise power as a function of frequency

%%
% * The lateral stick-to-|p| and rudder pedal-to-|beta| responses
% should match the handling quality targets |hq_p| and |hq_beta|.
% This is a model-matching objective: to minimize the difference (peak
% gain) between the desired and actual closed-loop transfer functions.
% Performance is limited due to a right-half plane zero in the model at
% 0.002 rad/sec, so accurate tracking of sinusoids below 0.002 rad/sec
% isn't possible. Accordingly, we'll weight the first handling quality spec
% with a bandpass filter |W_p| that emphasizes the frequency range between
% 0.06 and 30 rad/sec. (We prefer a roll rate tracking error of less than
% 5%).
figure(4)
W_p = tf([0.05 2.9 105.93 6.17 0.16],[1 9.19 30.80 18.83 3.95]);
clf, bodemag(W_p), title('Weight on Handling Quality spec')

%%
% *Figure 5:* Weight on handling quality spec.

%%
% Similarly, let's pick |W_beta=2*W_p| for the second handling quality spec

W_beta = 2*W_p;

%%
% Here we scaled the weights |W_act|, |W_n|, |W_p|, and |W_beta| so the
% closed-loop gain between all external inputs and all weighted outputs is
% less than 1 at all frequencies.


%% Nominal Aircraft Model
% A pilot can command the lateral-directional response of the aircraft with
% the lateral stick and rudder pedals. The aircraft has the following
% attributes:
%
% * Two control inputs: differential stabilizer deflection (delta_dstab,
% degrees) and rudder deflection (delta_rud, degrees).
% * Three measured outputs: roll rate (|p|, deg/sec), yaw rate (|r|,
% degs/sec), and lateral acceleration (|y_ac|, g's).
% * One calculated output: side-slip angle (|beta|).
%
% The nominal lateral directional F-14 model, the |F14nominal|, has
% four states:
%
% * Lateral velocity (|v|)
% * Yaw rate (|r|)
% * Roll rate (|p|)
% * Roll angle (|phi|)
%
% These variables are related by the state space equations:
%
% $$ \dot{x} = Ax+Bu, \;\; y   = Cx + Du$$
%
% where |x = [v; r; p; phi]|, |u = [delta_dstab; delta_rud]|, and
% |y = [beta; p; r; y_ac]|.

load F14.mat
F14nominal

%%
% The complete airframe model also includes actuators models |A_S| and
% |A_R|. The actuator outputs are their respective rates and deflections.
% The actuator rates are used to penalize the actuation effort.

A_S = [tf([25 0],[1 25]); tf(25,[1 25])];
A_R = A_S;


%% Accounting for Modeling Errors
% The nominal F14 model only approximates true airplane behavior. To
% account for unmodeled dynamics, you can introduce a relative introduce a
% relative term or multiplicative uncertainty |W_in*Delta_G| at the
% plant input, where the error dynamics |Delta_G| have gain less than 1
% across frequencies, and the weighting function |W_in| reflects the
% frequency ranges in which the model is more or less accurate. There are
% typically more modeling errors at high frequencies so |W_in| is high
% pass.

% Normalized error dynamics
Delta_G = ultidyn('Delta_G',[2 2],'Bound',1.0);

% Frequency shaping of error dynamics
w_1 = tf(2.0*[1 4],[1 160]);
w_2 = tf(1.5*[1 20],[1 200]);
W_in = append(w_1,w_2);

bodemag(w_1,'-',w_2,'--')
title('Relative error on nominal F14 model as a function of frequency')
legend('stabilizer','rudder','Location','NorthWest');

%%
% *Figure 6:* Relative error on nominal F-14 model as a function of
% frequency.

%% Building an Uncertain Model of the Aircraft Dynamics
% Now that we have quantified modeling errors, we can build an uncertain
% model of the aircraft dynamics corresponding to the dashed box in the
% figure 7 (same as figure 1):
%
% <<F14ICdiagram.jpg>>

%%
% *Figure 7:* Aircraft dynamics.

%%
% We'll use the |sysic| function to combine the nominal airframe model
% |F14nominal|, the actuator models |A_S| and |A_R|, and
% the modeling error description |W_in*Delta_G| into a single
% uncertain model mapping |[delta_dstab; delta_rud]| to the plant and
% actuator outputs:

systemnames = 'F14nominal A_S A_R W_in Delta_G';
inputvar = '[delta_dstab; delta_rud]';
outputvar = '[A_S; A_R; F14nominal]';
input_to_F14nominal = '[A_S(2); A_R(2)]';
input_to_A_S = '[delta_dstab + W_in(1)]';
input_to_A_R = '[delta_rud + W_in(2)]';
input_to_W_in = '[Delta_G]';
input_to_Delta_G = '[delta_dstab; delta_rud]';
sysoutname = 'F14_unc';
cleanupsysic = 'yes';
sysic;

%%
% This produces an uncertain state-space (USS) model |F14_unc| of the aircraft:
F14_unc

%% Analyzing How Modeling Errors Affect Open-Loop Responses
% We can analyze the effect of modeling uncertainty by picking random samples
% of the unmodeled dynamics |Delta_G| and plotting the nominal and
% perturbed time responses (Monte Carlo analysis). For example, for the
% differential stabilizer channel, the uncertainty weight |w_1| implies
% a 5% modeling error at low frequency, increasing to 100% after 93
% rad/sec, as confirmed by the Bode diagram below.

% Pick 10 random samples
F14_unc_sampl = usample(F14_unc,10);

% Look at response from differential stabilizer to beta
figure(5)
subplot(211), step(F14_unc.Nominal(5,1),'r+',F14_unc_sampl(5,1),'b-',10)
legend('Nominal','Perturbed'),ylabel('Beta (degrees)')

subplot(212), bodemag(F14_unc.Nominal(5,1),'r+',F14_unc_sampl(5,1),'b-',{0.001,1e3})
legend('Nominal','Perturbed')

figure(6);step(F14_unc_sampl(8,2))

%%
% *Figure 8:* Step response and Bode diagram.

%%  Designing the Lateral-Axis Controller
% Now we can proceed with designing a controller that robustly achieves
% the specifications, where robustly means for any perturbed aircraft
% model consistent with the modeling error bounds |W_in|.
%
% First we'll build an open-loop model |F14IC| mapping the external input
% signals to the performance-related outputs (see figure below).
%
% <<F14_generalplant.jpg>>

%%
% *Figure 9:* Open-loop model mapping external input signals to
% performance-related outputs.
%%
% Again we can use |sysic| to build |F14IC|:

systemnames = 'F14_unc antia_filt hq_p hq_beta ';
systemnames = [systemnames ' W_act W_n W_p W_beta'];
inputvar  = '[sn_nois{3}; roll_cmd; beta_cmd; delta_dstab; delta_rud]';
outputvar = '[ W_p; W_beta; W_act;  roll_cmd; beta_cmd; antia_filt + W_n ]';
input_to_F14_unc       = '[ delta_dstab; delta_rud ]';
input_to_antia_filt = '[ F14_unc(6:8) ]';
input_to_hq_beta = '[ beta_cmd ]';
input_to_hq_p    = '[ roll_cmd ]';
input_to_W_act      = '[ F14_unc(1:4) ]';
input_to_W_beta     = '[ hq_beta - F14_unc(5) ]';
input_to_W_p        = '[ hq_p - F14_unc(6) ]';
input_to_W_n        = '[ sn_nois ]';
sysoutname = 'F14IC';
cleanupsysic = 'yes';
sysic

%%
% This produces the uncertain state-space model
F14IC

%%
% Recall that by construction of the weighting functions, a controller
% meets the specs whenever the closed-loop gain is less than 1 at
% all frequencies and for any I/O directions. We can first design an
% H-infinity controller that minimizes the closed-loop gain for the nominal
% aircraft model:

nmeas = 5;		% number of measurements
nctrls = 2;		% number of controls
[kinf,ginf,gammainf] = hinfsyn(F14IC.NominalValue,nmeas,nctrls);
gammainf



%% Frequency-Domain Comparison of Controllers
% Let's compare the performance and robustness of the H-infinity
% controller |kinf| and mu controller |kmu|.  Recall that the performance
% specs are achieved when the closed loop
% gain is less than 1 for every frequency.
%
% First use the |lft| function to close the loop around each controller:

clinf = lft(F14IC,kinf);

%%
% What is the worst-case performance (in terms of closed-loop gain)
% of each controller for modeling errors bounded by |W_in|?
% The |wcgain| command helps you answer this difficult question directly
% without need for extensive gridding and simulation.

opt = wcgainOptions('MaxOverFrequency','off');  % options for WCGAIN


fmu = logspace(-2,2,60);
clinfg = ufrd(clinf,fmu)

% Compute worst-case gain (as a function of frequency) for kinf
[mginf,wcuinf] = wcgain(clinfg,opt);
mginf


%%
% The first plot shows that while the H-infinity controller |kinf| meets
% the performance specs for the nominal plant model, its
% performance can sharply deteriorate (peak gain near 15)
% for some perturbed model within our modeling error bounds.


%% Time-Domain Validation of the Robust Controller
% To further test the robustness of the mu controller |kmu| in the time
% domain, you can compare the time responses of the nominal and worst-case
% closed-loop models with the ideal "Handling Quality" response. To do this,
% first construct the "true" closed-loop model |F14SIM| where all weighting
% functions and HQ reference models have been removed:

systemnames = 'F14_unc antia_filt kinf';
inputvar  = '[roll_cmd; beta_cmd]';
outputvar = '[F14_unc(6); F14_unc(5)]';
input_to_F14_unc       = '[ kinf ]';
input_to_antia_filt = '[ F14_unc(6:8) ]';
input_to_kinf = '[ roll_cmd; beta_cmd; antia_filt ]';
sysoutname = 'F14SIM';
cleanupsysic = 'yes';
sysic

%%
% Next, create the test signals |u_stick| and |u_pedal| shown below

time = 0:0.02:15;
u_stick = (time>=9 & time<12);
u_pedal = (time>=1 & time<4) - (time>=4 & time<7);

figure(7)
subplot(211), plot(time,u_stick), axis([0 14 -2 2]), title('Lateral stick command')
subplot(212), plot(time,u_pedal), axis([0 14 -2 2]), title('Rudder pedal command')

%%
% You can now compute and plot the ideal, nominal, and worst-case responses
% to the test commands u_stick and u_pedal

% Ideal behavior
F14ideal = append(hq_p,hq_beta);

% Worst-case response
F14wc = usubs(F14SIM,wcuinf);

% Compare responses
clf
lsim(F14ideal,'g',F14SIM.NominalValue,'r',F14wc,'b--',[u_stick ; u_pedal],time)
legend('ideal','nominal','perturbed','Location','SouthEast');
title('Closed-loop responses with mu controller KMU')

