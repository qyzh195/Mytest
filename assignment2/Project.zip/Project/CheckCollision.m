function hit = CheckCollision(x1,x2,A,c)
%Students to add code that returns:
% hit = 1 if the line from x1 to x2 hits the ellipse (x-c)'A(x-c)<=1.
% hit = 0 otherwise (i.e. path is safe)


hit = 0;