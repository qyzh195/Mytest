function [ xdot ] = RobotDynamics(xt,ut,t, dynparams)
% Dynamics stub for AMME5520 Assignment 2. Students to fill in.



end

