function params = ComputePath(As,cs)

params = 0;