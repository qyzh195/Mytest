function [u,params] = ComputeControl(y,params)
% Students to add code here. You can use the "params" variable to store
% internal controller states, if necessary.

u = 0;